# PRO-C27-AA
Código de plantilla para la actividad del alumno para c27
